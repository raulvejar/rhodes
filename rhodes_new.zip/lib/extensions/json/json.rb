require 'json/common'
module JSON
  require 'json/version'
  require 'json/pure'
end
