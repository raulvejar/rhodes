#include "RhoNativeViewManager.h"


class ESRIViewFactorySingletone  {
public: 
  static NativeViewFactory* instance();
};
