Rhomobile debugger extension
-------------------------------------------------------------
Rhomobile debugger extension used by RhoStudio

More Info
-------------------------------------------------------------
  * Intro to Rhodes & RhoSync: <http://docs.rhomobile.com>
  * RhoStudio: <http://docs.rhomobile.com/rhostudio.tutorial>