str = "for i in (1..10); puts i; end"

#eval str
seq = __rho_compile(str)
puts "1111111111111111111"
puts seq.disasm
puts "1111111111111111111"
#seq.eval

arr = seq.to_a
puts "ar : #{arr}"
seq1 = RubyVM::InstructionSequence.load(arr)


puts seq1.disasm

seq1.eval